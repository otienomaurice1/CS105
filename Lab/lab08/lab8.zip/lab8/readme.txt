Otieno Maurice
CS105
LAB8
THE SEA WORM

This project entails a sketch to draw a ugly sea worm.
The sea worm is to be dark in color with purple spikes and green across its body  to make it more scary.
It's mouth is a circle with which it feeds by swallowing smaller insects and worms.
The sea worm moves by drifting across the dark,deep waters of the Dead sea since it is very light.
The sea worm is to be draw by first analysing its cross-section. The cross section consists of a shape like that of a star with many points.
The outer vertice is to be located significantly farther away from the inner to give the spike effect.
Several of these cross sections make up the worm. Think of the worm as a body formed by intergrating this cross section along a given length.
The size of the sea worm is to depend on the size of canvas and its length is to depend on the number of cross sections as defined by the user.
This project was influenced by my desire to explore the stranges things in the universe especially in the seas and oceans.
Who knows what lives down there. Imagine coming across one of those creatures while swimming in Australia. I imagine how muchh fun that would be.
Dark! haha. The main challenge was encountered in trying to move the warm. 